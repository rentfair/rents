	icon: https://s.roomster.com/Content/favicons/mstile-144x144.png?20170206-2
	background: https://s.roomster.com/Content/images/hplocal/?20170206-2&country=bd&city=
	logo: https://s.roomster.com/Content/images/logo_full.png?635900965620957031
	
	domain: roomzter.com